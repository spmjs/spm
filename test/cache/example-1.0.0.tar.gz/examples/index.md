# DEMO

---

````js
seajs.use('src/base', function(Base) {
  console.log(new Base());
});
````
